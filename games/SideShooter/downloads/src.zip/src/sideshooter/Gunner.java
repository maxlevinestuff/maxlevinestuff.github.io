package sideshooter;
import java.awt.Rectangle;
public class Gunner extends Enemy {
    final int BOXSIZE = 100;
    Gunner() {
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
    }
    @Override
    Boolean refresh() {
        y += (Math.sin(sine)+0.5*Math.sin(2*sine))*4;
        if (SideShooter.time < 5000)
            x -= SideShooter.time/600+7;
        else
            x -= 5000/600+7;
        sine += 0.1;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
        return super.refresh();
    }
    @Override
    public String toString() {
        return "Gunner";
    }
}