package sideshooter;
import java.awt.Rectangle;
public class Bullet extends GameObject {
    final int BOXSIZE = 50;
    Bullet() {
        x = SideShooter.GameObjectList.get(0).x+100;
        y = SideShooter.GameObjectList.get(0).y;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
    }
    @Override
    Boolean refresh() {
        if (SideShooter.health > 0 && SideShooter.GameObjectList.getFirst().getClass()==Player.class) {
            x += 100;
            hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
            return super.refresh();
        } else {
            return true;
        }
    }
    @Override
    void draw() {if (SideShooter.health > 0 && SideShooter.GameObjectList.getFirst().getClass()==Player.class) StdDraw.picture(x,y,toString() + ".png",100,50,180);}
    @Override
    public String toString() {
        return "Bullet";
    }
    @Override
    Boolean collisions() {return false;}
}