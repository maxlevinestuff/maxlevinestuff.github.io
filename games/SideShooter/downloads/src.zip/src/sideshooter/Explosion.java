package sideshooter;
import java.awt.Rectangle;
import java.util.Random;
public class Explosion extends GameObject {
    final int BOXSIZE = 100;
    int explosive;
    Random gen = new Random();
    Explosion(int xTemp, int yTemp) {
        x = xTemp;
        y = yTemp;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
        explosive = 0;
    }
    @Override
    Boolean refresh() {
        hitBox = new Rectangle(x,y,explosive,explosive);
        explosive += 20;
        if (explosive >= 200) {
            return true;
        } else {
            return false;
        }
    }
    @Override
    void draw() {
        if (gen.nextBoolean()) {
            StdDraw.picture(x,y,"ExplosionA.png",explosive,explosive,explosive);
        } else {
            StdDraw.picture(x,y,"ExplosionB.png",explosive,explosive,explosive);
        }
    }
    @Override
    Boolean collisions() {return false;}
}
