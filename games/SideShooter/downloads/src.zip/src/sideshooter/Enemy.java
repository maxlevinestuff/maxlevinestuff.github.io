package sideshooter;
import java.util.Random;
public abstract class Enemy extends GameObject {
    double sine = 0;
    Boolean invaded = false;
    Enemy() {
        Random gen = new Random();
        x = SideShooter.SCALE+400;
        y = gen.nextInt(SideShooter.SCALE/2);
        sine = y;
    }
    @Override
    Boolean collisions() {
        if (SideShooter.health > 0) {
            for (GameObject g : SideShooter.GameObjectList) {
                if (!(g.getClass().getSuperclass()==Enemy.class||g.getClass().getSuperclass().getSuperclass()==Enemy.class)) { //collision exceptions
                    if (hitBox.intersects(g.hitBox)) {
                        explosion();
                        g.destroyIfBullet();
                        return true;
                    }
                }
            }
        }
        return false;
    }
    @Override
    Boolean refresh() {
        if (x < 200 && !invaded && SideShooter.health > 0) {
            invaded = true;
            SideShooter.health -= 10;
        }
        return super.refresh();
    }
}