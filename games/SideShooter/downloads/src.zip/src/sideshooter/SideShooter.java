package sideshooter;
import java.awt.event.KeyEvent;
import java.util.LinkedList;
import java.util.Random;
import java.util.Iterator;
import java.awt.Font;
public class SideShooter {
    static Font font = new Font("Dialogue", Font.BOLD, 24);
    static public Random gen = new Random();
    static public int time;
    static public LinkedList<GameObject> GameObjectList = new LinkedList<>();
    static public LinkedList<Colonist> ColonistList = new LinkedList<>();
    static public final int SCALE = 3000;
    static public int health = 100;
    static MessageDisplay display = new MessageDisplay();
    //begin moonpath variables
    static private double theta = 45;
    static private double moonX = 0;
    static private double moonY = 0;
    //end moonpath variables
    static private Boolean colonized = false;
    static private int colonistTotal;
    static private int kamakazeNumber;
    static public LinkedList<Integer> xExplosion = new LinkedList<>();
    static public LinkedList<Integer> yExplosion = new LinkedList<>();
    static Boolean phase1 = false;
    static Boolean phase2 = false;
    static Boolean phase3 = false;
    static Boolean phase4 = false;
    static int genPerm;
    static int finalScore;
    static private void enemyMaker() {
        int genMax;
        if (health > 0) {
            genMax = time/450+4;
            genPerm = genMax;
        } else {
            genMax = genPerm;
        }
        if (genMax > 14) {
            genMax = 14;
        }
        switch(gen.nextInt(genMax)) {
            case 1: case 2: case 3: case 4:
                GameObjectList.add(new Clone());
                if (!phase1) {phase1 = true; display.newMessage(SCALE/2,SCALE/4,"PHASE 1",150);}
                break;
            case 5: case 6: case 7:
                GameObjectList.add(new Drone());
                if (!phase2) {phase2 = true; display.newMessage(SCALE/2,SCALE/4,"PHASE 2",150);}
                break;
            case 8: case 9: case 10: case 11:
                GameObjectList.add(new Gunner());
                if (!phase3) {phase3 = true; display.newMessage(SCALE/2,SCALE/4,"PHASE 3",150);}
                break;
            case 12: case 13: case 14:
                GameObjectList.add(new Destroyer());
                if (!phase4) {phase4 = true; display.newMessage(SCALE/2,SCALE/4,"PHASE 4",150);}
                break;
        }
    }
    public static void main(String[] args) {
        StdDraw.setCanvasSize(1000,500);
        StdDraw.setYscale(0,SCALE/2);
        StdDraw.setXscale(0,SCALE);
        StdDraw.setPenColor(StdDraw.YELLOW);
        StdDraw.setFont(font);
        GameObjectList.add(new Player());
        time = 0;
        Sound s = new Sound(); s.start();
        while (true) {
            time++;
            //refresh all game objects
            Iterator<GameObject> iterator = GameObjectList.iterator();
            while (iterator.hasNext()) {
                if (iterator.next().refresh()) {
                    iterator.remove();
                }
            }
            //explosions
            for (int x : xExplosion) {
                for (int y : yExplosion) {
                    GameObjectList.add(new Explosion(x,y));
                }
            }
            xExplosion.clear();
            yExplosion.clear();
            //end explosions
            display.newMessage(SCALE/2,SCALE/45,time*1000+"",2);
            display.newMessage(SCALE/2,SCALE/130-20,"COLONISTS ESCAPED",1,15);
            if (health==0) {
                if (!colonized) {
                    colonized = true;
                    colonistTotal = time/800;
                    finalScore = time;
                }
                display.clear();
                display.newMessage(SCALE/2,SCALE/4,"You saved " + finalScore*1000 + " humans. Press R to restart.",1);
                if (time%27==0 && colonistTotal > 0) {
                    colonistTotal--;
                    ColonistList.add(new Colonist());
                }
                for (int x = 0; x < SCALE/4-300; x+=200) {
                    for (int y = 0; y < SCALE/2; y+=200) {
                        GameObjectList.add(new Explosion(x+gen.nextInt(600)-300,y+gen.nextInt(600)-300));
                    }
                }
            }
            Iterator<Colonist> colonistIterator = ColonistList.iterator();
            while (colonistIterator.hasNext()) {
                if (colonistIterator.next().refresh()) {
                    colonistIterator.remove();
                }
            }
            //add new enemy
            kamakazeNumber = 100-time/60;
            if (kamakazeNumber < 20) {
                kamakazeNumber = 20;
            }
            if (time%(kamakazeNumber) == 0) {
                GameObjectList.add(new Kamakaze());
            }
            if (time%6 == 0) {
                enemyMaker();
            }
            //begin moon refresh
            theta = theta + Math.toRadians(-0.2);
            moonX = -350 + 3000*Math.cos(theta);
            moonY = SCALE/4 + 3000*Math.sin(theta);
            //end moon refresh
            //use gun
            if ((StdDraw.isKeyPressed(KeyEvent.VK_SPACE))&&(time%7==0)) {
                GameObjectList.add(new Bullet());
            }
            iterator = GameObjectList.iterator();
            while (iterator.hasNext()) {
                if (iterator.next().collisions()) {
                    iterator.remove();
                }
            }
            //RESET GAME
            if (health == 0 && StdDraw.isKeyPressed(KeyEvent.VK_R)) {
                health = 100;
                colonized = false;
                GameObjectList.clear();
                ColonistList.clear();
                GameObjectList.add(new Player());
                display.clear();
                time = 0;
                phase1 = false;
                phase2 = false;
                phase3 = false;
                phase4 = false;
                genPerm = 4;
            }
            //graphics
            StdDraw.clear();
            StdDraw.picture(SCALE/2+10,SCALE/4,"Background.png",SCALE+680,SCALE+680,time);
            StdDraw.picture(moonX,moonY,"Moon.png",1250,1250,time);
            StdDraw.picture(-350,SCALE/4,"Earth.png",2000,2000,-time/2);
            for (Colonist c : ColonistList) {
                c.draw();
            }
            for (GameObject g : GameObjectList) {
                g.draw();
            }
            display.refresh();
            //begin hitbox
            //for (GameObject g : GameObjectList)
            //    StdDraw.rectangle(g.hitBox.x,g.hitBox.y,g.hitBox.width/2,g.hitBox.height/2);
            //end hitbox
            StdDraw.show(1);
        }
    }
}