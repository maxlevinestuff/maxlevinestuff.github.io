package sideshooter;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
public class Sound extends Thread {
    @Override
    public void run() {
        while (true) {
            try {
                AudioPlayer.player.start(new AudioStream(SideShooter.class.getResourceAsStream("music.wav")));
            } catch(Exception e) {}
            try {
                Thread.sleep(17000);
            } catch (InterruptedException e) {}
        }
    }
}