package sideshooter;
import java.awt.Rectangle;
public class Drone extends Enemy {
    final int BOXSIZE = 100;
    Drone() {
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
    }
    @Override
    Boolean refresh() {
        y += (-Math.sin(sine))*3;
        if (SideShooter.time < 5000)
            x -= SideShooter.time/600+5;
        else
            x -= 5000/600+5;
        sine += 0.1;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
        return super.refresh();
    }
    @Override
    public String toString() {
        return "Drone";
    }
}