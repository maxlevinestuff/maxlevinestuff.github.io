package sideshooter;
import java.util.Random;
public class Colonist extends GameObject {
    double sine;
    Colonist() {
        Random gen = new Random();
        x = -399;
        y = SideShooter.SCALE/4+gen.nextInt(400)-300;
        sine = y;
    }
    @Override
    Boolean refresh() {
        sine += 0.1;
        y += Math.sin(sine)*5;
        x += 30;
        return super.refresh();
    }
    @Override
    void draw() {
        StdDraw.picture(x,y,"Colonist.png",600,400,180);
    }
    @Override
    public String toString() {
        return "Colonist";
    }
}
