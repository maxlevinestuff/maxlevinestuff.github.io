package sideshooter;
import java.awt.Rectangle;
public abstract class GameObject {
    void explosion() {
        SideShooter.xExplosion.add(x);
        SideShooter.yExplosion.add(y);
    }
    Rectangle hitBox;
    int x;
    int y;
    int xVelocity;
    int yVelocity;
    Boolean refresh() {return ((x > SideShooter.SCALE+400)||(x < -400)||(y > SideShooter.SCALE/2+400)||(y < -400));} //if game object is offscreen, destroy it
    Boolean collisions() {return true;}
    @Override
    public String toString() {return "GameObject";}
    void destroyIfBullet() {if (getClass()==Bullet.class) {x=5000;}}
    void draw() {StdDraw.picture(x,y,toString() + ".png",150,150,0);}
}