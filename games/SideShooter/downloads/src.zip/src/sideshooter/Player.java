package sideshooter;
import java.awt.event.KeyEvent;
import java.awt.Rectangle;
public class Player extends GameObject {
    final int BOXSIZE = 100;
    Player() {
        x = SideShooter.SCALE/4;
        y = SideShooter.SCALE/4;
        xVelocity = 0;
        yVelocity = 0;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
    }
    @Override
    void draw() {if (SideShooter.health > 0) {StdDraw.picture(x,y,toString() + ".png",150,200,90);}}
    @Override
    Boolean refresh() {
        //adjust velocity
        if (StdDraw.isKeyPressed(KeyEvent.VK_UP)) {
            yVelocity += 2;
        }
        if (StdDraw.isKeyPressed(KeyEvent.VK_DOWN)) {
            yVelocity -= 2;
        }
        if (StdDraw.isKeyPressed(KeyEvent.VK_RIGHT)) {
            xVelocity += 2;
        }
        if (StdDraw.isKeyPressed(KeyEvent.VK_LEFT)) {
            xVelocity -= 2;
        }
        if (yVelocity > 0) {
            yVelocity -= 1;
        } else if (yVelocity < 0) {
            yVelocity += 1;
        }
        if (xVelocity > 0) {
            xVelocity -= 1;
        } else if (xVelocity < 0) {
            xVelocity += 1;
        }
        //deploy velocity
        x += xVelocity;
        y += yVelocity;
        //stay in bounds
        if (x < 0) {
            x = 0;
            xVelocity = 0;
        }
        if (x > SideShooter.SCALE) {
            x = SideShooter.SCALE;
            xVelocity = 0;
        }
        if (y < 0) {
            y = 0;
            yVelocity = 0;
        }
        if (y > SideShooter.SCALE/2) {
            y = SideShooter.SCALE/2;
            yVelocity = 0;
        }
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
        return false;
    }
    @Override
    public String toString() {
        return "Player";
    }
    @Override
    Boolean collisions() {
        if (SideShooter.health > 0) {
            for (GameObject g : SideShooter.GameObjectList) {
                if (!(g.getClass()==Bullet.class)&&!(g.getClass()==Player.class)) {
                    if (hitBox.intersects(g.hitBox)) {
                        explosion();
                        return true;
                    }
                }
            }
        }
        return false;
    }
}