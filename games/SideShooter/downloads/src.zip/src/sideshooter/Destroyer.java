package sideshooter;
import java.awt.Rectangle;
public class Destroyer extends Enemy {
    final int BOXSIZE = 100;
    Destroyer() {
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
    }
    @Override
    Boolean refresh() {
        y += (-Math.sin(sine))*5;
        if (SideShooter.time < 5000)
            x -= SideShooter.time/600+4;
        else
            x -= 5000/600+4;
        sine += 0.1;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
        return super.refresh();
    }
    @Override
    public String toString() {
        return "Destroyer";
    }
}