package sideshooter;
import java.awt.Rectangle;
import java.util.Random;
public class Kamakaze extends Enemy {
    final int BOXSIZE = 100;
    Random gen = new Random();
    Boolean cometType = gen.nextBoolean();
    int speed;
    Kamakaze() {
        Random gen = new Random();
        speed = gen.nextInt(6)+5;
        y = SideShooter.SCALE/2+400;
        x = gen.nextInt(SideShooter.SCALE);
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
    }
    @Override
    void draw() {
        if (cometType) {
            StdDraw.picture(x,y,"Kamakaze.png",150,150,SideShooter.time+speed*100);
        } else {
            StdDraw.picture(x,y,"Comet.png",150,150,SideShooter.time+speed*100);
        }
        if (SideShooter.SCALE/2+105 < y)
            StdDraw.picture(x,SideShooter.SCALE/2+(Math.sin(sine*6)*7+37),"Down.png",75,75);
    }
    @Override
    Boolean refresh() {
        x += Math.cos(sine)*(speed-7)-4;
        y -= speed;
        sine += 0.1;
        hitBox = new Rectangle(x,y,BOXSIZE,BOXSIZE);
        return ((x > SideShooter.SCALE+400)||(x < -400)||(y > SideShooter.SCALE/2+400)||(y < -400));
    }
    @Override
    public String toString() {
        return "Kamakaze";
    }
}
