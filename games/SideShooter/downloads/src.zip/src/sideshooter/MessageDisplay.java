package sideshooter;
import java.util.LinkedList;
import java.util.Iterator;
import java.awt.Font;
public class MessageDisplay {
    private LinkedList<Message> messageList = new LinkedList<>();
    void refresh() {
        Iterator<Message> iterator = messageList.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().refresh()) {
                iterator.remove();
            }
        }
    }
    void clear() {
        messageList.clear();
    }
    void newMessage(int xTemp, int yTemp, String messageTemp, int timeTemp) {
        messageList.add(new Message(xTemp,yTemp,messageTemp,timeTemp));
    }
    void newMessage(int xTemp, int yTemp, String messageTemp, int timeTemp, int fontSize) {
        messageList.add(new Message(xTemp,yTemp,messageTemp,timeTemp,fontSize));
    }
    private class Message {
        Message(int xTemp, int yTemp, String messageTemp, int timeTemp) {
            x = xTemp;
            y = yTemp;
            message = messageTemp;
            time = timeTemp;
            font = new Font("Dialogue", Font.BOLD, 24);
        }
        Message(int xTemp, int yTemp, String messageTemp, int timeTemp, int fontSize) {
            x = xTemp;
            y = yTemp;
            message = messageTemp;
            time = timeTemp;
            font = new Font("Dialogue", Font.BOLD, fontSize);
        }
        Font font;
        int x;
        int y;
        String message;
        int time;
        Boolean refresh() {
            StdDraw.setFont(font);
            StdDraw.text(x,y,message);
            time--;
            if (time <= 0) {
                return true;
            } else {
                return false;
            }
        }
    }
}