package Giant;
import java.util.Random;
public class crushables {
	private int x;
	private boolean isTree;
	private boolean crushed;
	int getX() {
		return x;
	}
	String getType() {
		if (crushed) {
			if (isTree) {
				return "crushedTree.png";
			} else {
				return "crushedBuilding.png";
			}
		} else {
			if (isTree) {
				return "trees.png";
			} else {
				return "buildings.png";
			}
		}
	}
	crushables() {
		crushed = false;
		Random gen = new Random();
		x = 130;
		isTree = gen.nextBoolean();
	}
	void refresh(foot newFoot) {
		if (!newFoot.getOnGround()) {
			x -= 1;
		}
		if (newFoot.getStomping() && x > 0 && x < 45) {
			if (!crushed) {
				if (isTree) {
					Giant.score -= 5;
					Giant.lastCrushed = 0;
                                        Giant.totalCrushed += 1;
				} else {
					Giant.score += 1;
					Giant.lastCrushed = 1;
				}
			}
			crushed = true;
		}
		if (x < -20) {
			x = 130;
			crushed = false;
			Random gen = new Random();
			isTree = gen.nextBoolean();
		}
	}
}
