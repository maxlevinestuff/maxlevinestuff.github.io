package Giant;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.util.Random;
public class Giant {
        static int score = 0;
	static int highScore = 0;
        static int time = 0;
        static int totalCrushed = 0;
	static int lastCrushed = -1;
	static String splashText = "";
	static Random gen = new Random();
	static void splash(String text) {
		splashText = text;
	}
	static void buildingText() {
		int text = gen.nextInt(5);
		switch(text) {
		case 1:
			splash("That city definitely deserved it.");
			break;
		case 2:
			splash("Humans were crushed.");
			break;
		case 3:
			splash("One less city in the world.");
			break;
		case 4:
			splash(gen.nextInt(25)+3000 + " humans were crushed.");
			break;
		}
		lastCrushed = -1;
	}
	static void treeText() {
		int text = gen.nextInt(6);
		switch(text) {
		case 1:
			splash("Don't crush forests.");
			break;
		case 2:
			splash("You killed a poor little squirrel.");
			break;
		case 3:
			splash("Trees never did anything to you.");
			break;
		case 4:
			splash(gen.nextInt(25)+25 + " trees were crushed.");
			break;
		case 5:
			splash("Where do you think your oxygen comes from?");
			break;
		}
		lastCrushed = -1;
	}
	static void splashText() {
		if (lastCrushed != -1) {
			if (lastCrushed == 1) {
				buildingText();
			} else {
				treeText();
			}
		}
	}
	public static void main(String[] args) {
                Sound s = new Sound(); s.start();
		StdDraw.setCanvasSize(1000, 500);
                boolean lost = false;
		StdDraw.setScale(0, 100);
                while (true) {
                    score = 0;
        time = 0;
        totalCrushed = 0;
	lastCrushed = -1;
	 splashText = "";
         lost = false;
		Font font = new Font("Dialogue", Font.BOLD, 14);
		StdDraw.setFont(font);
		crushables[] refreshList = new crushables[9];
		foot newFoot = new foot();
		StdDraw.setPenColor(StdDraw.BLUE);
		BackGround grass = new BackGround();
		cloud newCloud = new cloud();
		while (true) {
			time += 1;
			if (time%19 == 0) {
				if(time / 19 < 9) {
					refreshList[time/19] = new crushables();
				}
			}
			for (int n = 0; n < 9; n++) {
				try {
					refreshList[n].refresh(newFoot);
				} catch(NullPointerException e) {
					; //do nothing
				}
			}
			newFoot.refresh();
			newCloud.refresh(newFoot);
			grass.refresh(newFoot);
			splashText();
			if (score < 0) {
				score = 0;
			}
			if (score > highScore) {
				highScore = score;
			}
			StdDraw.clear();
		StdDraw.picture(grass.getX(), 29, "ground.png", 320, 160);
		StdDraw.picture(100, 90, "sun.png",Math.sin(time/6)+22,Math.sin(time/6)+40);
		if (!newFoot.getOnGround()) {
			StdDraw.picture(Math.sin(time/5)*6+39, Math.sin(time/5)*6+75, "foot.png", 40, 80, -Math.sin(time/5)*6);
			StdDraw.picture(Math.sin(time/5*6)+90, Math.sin(time/5)*6+120, "fist.png", 40, 80, Math.sin(time/5)*6);
			StdDraw.picture(newFoot.getX(), newFoot.getY()+18, "foot.png", 40, 80, Math.sin(time/10));
		} else {
			StdDraw.picture(39, 75, "foot.png", 40, 80);
			StdDraw.picture(90, 120, "fist.png", 40, 80, Math.sin(time/2*5));
			StdDraw.picture(newFoot.getX(), newFoot.getY()+18, "foot.png", 40, 80, Math.sin(time/3)*5);
		}
		if (time / 19 < 9) {
			StdDraw.picture(-time+130, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+115, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+100, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+85, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+70, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+55, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+40, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+25, 46,"trees.png", 20, 40);
			StdDraw.picture(-time+10, 46,"trees.png", 20, 40);
			StdDraw.picture(-time-5, 46,"trees.png", 20, 40);
		}
		for (int n = 0; n < 9; n++) {
			try {
				StdDraw.picture(refreshList[n].getX(), 46, refreshList[n].getType(), 20, 40);
			} catch(NullPointerException e) {
				; //do nothing
			}
		}
		StdDraw.picture(newCloud.getX(), newCloud.getY(), "cloud.png", 50, 50);
		if (time / 19 < 3) {
			StdDraw.picture(50,60,"3.png",20,40);
		} else if (time / 19 < 6) {
			StdDraw.picture(50,60,"2.png",20,40);
		} else if (time / 19 < 9) {
			StdDraw.picture(50,60,"1.png",20,40);
		} else if (time / 19 < 14) {
			StdDraw.picture(50,60,"go.png",45,40);
		}
                for (int i = 0; i < totalCrushed; i++) {
                    StdDraw.picture((5*i),1,"X.png",5,10);
                }
                if (totalCrushed >= 3 && lost == false) {
                    lost = true;
                    time = 500;
                }
                if (time >= 504 && lost == true) {
                    break;
                }
		if (time / 19 < 23) {
			StdDraw.setPenColor(StdDraw.GREEN);
			StdDraw.textLeft(26, 14.5, "Humans are a disease. Crush their cities, but don't crush the forest.");
			StdDraw.textLeft(27.1,9.9, "Press");
                        StdDraw.textLeft(46.2,9.9, "SPACEBAR");
                        StdDraw.textLeft(69.8,9.9, "to crush.");
			if ((Math.round(time/10)*10)%50 == 0) {
				StdDraw.picture(50, 11.4, "downBar.png", 40, 20);
			} else {
				StdDraw.picture(50, 11.4, "upBar.png", 40, 20);
			}
			StdDraw.setPenColor(StdDraw.RED);
		} else {
			StdDraw.setPenColor(StdDraw.GREEN);
                        if (lost == true) {
                            if (highScore <= 7) {
                                splashText = "You crushed too many forests. Your final score is " + highScore + ". Do better next time.";
                            } else if (highScore > 7 && highScore <= 50) {
                                splashText = "You crushed too many forests. Your final score is " + highScore + "! Good work!";
                            } else {
                                splashText = "You crushed too many forests. Your final score is " + highScore + "! Great work!";
                            }
                        }
			StdDraw.text(50, 8.5, splashText);
			StdDraw.setPenColor(StdDraw.RED);
		}
		StdDraw.textRight(103.5, 96, ("Score: " + score));
		StdDraw.textRight(103.5, 100, ("High score: " + highScore));
                if (lost == true) {
                    StdDraw.textRight(103.5, 90, "GAME OVER");
                    break;
                }
		StdDraw.show(2);
		}
                StdDraw.setPenColor(StdDraw.GREEN);
                StdDraw.textLeft(27.1,3, "Press");
                        StdDraw.textLeft(46.2,3, "SPACEBAR");
			StdDraw.picture(50, 4.5, "upBar.png", 40, 20);
                StdDraw.show(2);
                while (!StdDraw.isKeyPressed(KeyEvent.VK_SPACE)) {}
                while (StdDraw.isKeyPressed(KeyEvent.VK_SPACE)) {}
                while (!StdDraw.isKeyPressed(KeyEvent.VK_SPACE)) {}
                }
	}
}