package Giant;
import java.awt.event.KeyEvent;
public class foot {
	private int x;
	private int y;
	private boolean stomping;
	private boolean keyPressed;
	private boolean onGround;
	foot() {
		x = 20;
		y = 90;
		stomping = false;
	}
	int getX() {
		return x;
	}
	int getY() {
		return y;
	}
	boolean getStomping() {
		return stomping;
	}
	void refresh() {
		if (StdDraw.isKeyPressed(KeyEvent.VK_SPACE) && Giant.time / 19 > 9) {
			keyPressed = true;
			if (y > 50) {
				stomping = true;
				y -= 10;
			} else {
				stomping = false;
			}
		} else {
			keyPressed = false;
		}
		if (y < 90 && !keyPressed) {
			y += 5;
	}
		if (y < 50) {
			y = 50;
		}
		if (y > 90) {
			y = 90;
		}
		if (!keyPressed) {
			stomping = false;
		}
		if (keyPressed && stomping == false) {
			onGround = true;
		} else {
			onGround = false;
		}
	}

    boolean getOnGround() {
        return onGround;
    }
}