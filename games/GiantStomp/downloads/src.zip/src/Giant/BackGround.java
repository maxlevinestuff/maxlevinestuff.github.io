package Giant;
public class BackGround {
	private int x;
	int getX() {
		return x;
	}
	BackGround() {
		x = 140;
	}
	void refresh(foot newFoot) {
		if (!newFoot.getOnGround()) {
			x -= 1;
		}
		if (x < -50) {
			x = 140;
		}
	}
}
