package Giant;
import java.util.Random;
public class cloud {
	private double x;
	private int y;
	double getX() {
		return x;
	}
	int getY() {
		return y;
	}
	cloud() {
		Random gen = new Random();
		x = 130;
		y = gen.nextInt(60)+110;
	}
	void refresh(foot newFoot) {
		if (!newFoot.getOnGround()) {
			x -= 0.5;
		} else {
			x -= 0.125;
		}
		if (x < -40) {
			x = 130;
			Random gen = new Random();
			y = gen.nextInt(60)+68;
		}
	}
}
