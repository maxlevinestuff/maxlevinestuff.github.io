Use Processing 3 to open the PDE file. The bare minimum you need (and what was used mainly to develop) is “Swarm_Saucers.pde” and the unaltered “data” folder inside the “Swarm_Saucers” folder. Be warned: code is very messy and unorganized and uses very poor practices and is uncommented :)

Special thanks
Wolfram Tones
Soundbible
Stack Overflow
Processing.org
Adobe
Audacity
Desmos
Google